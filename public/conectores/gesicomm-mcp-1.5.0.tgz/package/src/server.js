import { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import { z } from 'zod';
import { GesicommApiClient } from './apiClient.js';

import { registrarProductos } from './productos.js';

export function createGesicommServer(config = {}) {
  const client = new GesicommApiClient(config);
  const defaultLandingId = process.env.GESICOMM_LANDING_ID ? Number(process.env.GESICOMM_LANDING_ID) : null;

  const server = new McpServer({
    name: 'gesicomm-mcp',
    version: '1.5.0',
  });

  const resultado = datos => ({ content: [{ type: 'text', text: JSON.stringify(datos) }] });
  server.tool('gesicomm_listar_tiendas', 'Muestra las tiendas propias. Preguntá cuál usar cuando el pedido no la identifique.', {}, async () => resultado(await client.listarTiendas()));
  const porTienda = {
    tool(nombre, descripcion, esquema, ejecutar) {
      server.tool(nombre, descripcion, { ...esquema, tienda_id: z.number().int().positive().optional().describe('Tienda elegida por el usuario para este pedido') }, async args => {
        const tiendas = await client.listarTiendas();
        const id = args.tienda_id ?? args.tienda_confirmada ?? (tiendas.length === 1 ? tiendas[0].id : null);
        if (!tiendas.some(t => t.id === id) || (args.tienda_confirmada && args.tienda_confirmada !== id)) {
          return resultado({ estado: 'elegir_tienda', pregunta: '¿En qué tienda querés trabajar?', tiendas });
        }
        return client.seleccion.run(id, () => ejecutar(args));
      });
    },
  };
  registrarProductos(porTienda, client);

  // Tool 1: Listar Landings
  porTienda.tool(
    'gesicomm_listar_landings',
    'Lista las landings activas y en borrador de la tienda en Gesicomm para conocer sus IDs y títulos.',
    {},
    async () => {
      try {
        const landings = await client.listarLandings();
        return {
          content: [{
            type: 'text',
            text: JSON.stringify(landings, null, 2),
          }],
        };
      } catch (err) {
        return {
          isError: true,
          content: [{ type: 'text', text: `Error al listar landings: ${err.message}` }],
        };
      }
    }
  );

  // Tool 2: Obtener Contexto Comercial Completo
  porTienda.tool(
    'gesicomm_obtener_contexto_landing',
    'Obtiene el contexto comercial completo de la landing: catálogo de productos con precios en Guaraníes (PYG), imágenes, variantes, ofertas (order bumps, packs), branding de la tienda y el contrato técnico de directivas obligatorias para que el carrito, los pedidos y el Píxel funcionen.',
    {
      landing_id: z.number().int().positive().optional().describe('ID numérico de la landing en Gesicomm (si se omite, usa GESICOMM_LANDING_ID)'),
    },
    async ({ landing_id }) => {
      const id = landing_id || defaultLandingId;
      if (!id) {
        return {
          isError: true,
          content: [{ type: 'text', text: 'Debes proporcionar landing_id o configurar GESICOMM_LANDING_ID.' }],
        };
      }
      try {
        const contexto = await client.obtenerContexto(id);
        if (!contexto) {
          throw new Error(`No se pudo obtener el contexto de la landing #${id}. Verificá que la landing exista y pertenezca a tu tienda.`);
        }
        return {
          content: [{
            type: 'text',
            text: JSON.stringify(contexto, null, 2),
          }],
        };
      } catch (err) {
        return {
          isError: true,
          content: [{ type: 'text', text: `Error al obtener contexto comercial de la landing #${id}: ${err.message}` }],
        };
      }
    }
  );

  // Tool 3: Leer Código de la Landing
  porTienda.tool(
    'gesicomm_leer_codigo_landing',
    'Lee el código actual (HTML, CSS, JS) de una vista específica de la landing (inicio, producto, catalogo, categoria, checkout, legal) para poder inspeccionarlo, mejorarlo o modificarlo.',
    {
      landing_id: z.number().int().positive().optional().describe('ID numérico de la landing'),
      vista: z.enum(['inicio', 'producto', 'catalogo', 'categoria', 'checkout', 'legal']).default('inicio').describe('Vista a consultar'),
      seccion_id: z.string().regex(/^[a-zA-Z0-9_]+$/).optional().describe('Bloque de inicio a leer o editar (ej: anuncios). Omitir al leer para descubrir secciones.'),
      content_id: z.string().optional().describe('Para fichas propias de un producto específico, el content_id (ej: "producto-15")'),
    },
    async ({ landing_id, vista, content_id, seccion_id }) => {
      const id = landing_id || defaultLandingId;
      if (!id) {
        return {
          isError: true,
          content: [{ type: 'text', text: 'Debes proporcionar landing_id o configurar GESICOMM_LANDING_ID.' }],
        };
      }
      try {
        const data = await client.obtenerCodigo(id, vista, content_id, seccion_id);
        return {
          content: [{
            type: 'text',
            text: JSON.stringify(data, null, 2),
          }],
        };
      } catch (err) {
        return {
          isError: true,
          content: [{ type: 'text', text: `Error al leer código de la landing #${id}: ${err.message}` }],
        };
      }
    }
  );

  // Tool 4: Validar Motor Comercial
  porTienda.tool(
    'gesicomm_validar_motor_comercial',
    'Audita un fragmento o documento HTML antes de guardarlo, verificando que tenga los botones de compra (data-gesicomm-comprar/agregar), casillas de order bump, selector de variantes y binds de precios necesarios para procesar pedidos y activar el Píxel de Meta.',
    {
      html: z.string().describe('Código HTML a validar'),
      vista: z.enum(['inicio', 'producto', 'catalogo', 'categoria', 'checkout', 'legal']).default('inicio').describe('Vista a validar'),
      landing_id: z.number().int().positive().optional().describe('ID de la landing (opcional)'),
    },
    async ({ html, vista, landing_id }) => {
      const id = landing_id || defaultLandingId;
      try {
        let res;
        if (id) {
          res = await client.validarCodigo(id, html, vista);
        } else {
          // Validación local básica si no hay id
          const tieneComprar = /data-gesicomm-comprar/.test(html) || /data-gesicomm-agregar/.test(html);
          res = {
            valido: tieneComprar,
            errores: tieneComprar ? [] : ['Falta botón de compra: El HTML debe contener data-gesicomm-comprar o data-gesicomm-agregar.'],
            advertencias: [],
            sugerencias: [],
          };
        }
        return {
          content: [{
            type: 'text',
            text: JSON.stringify(res, null, 2),
          }],
        };
      } catch (err) {
        return {
          isError: true,
          content: [{ type: 'text', text: `Error en validación: ${err.message}` }],
        };
      }
    }
  );

  // Tool 5: Guardar Código en Gesicomm
  porTienda.tool(
    'gesicomm_guardar_codigo_landing',
    'Si el pedido no identifica la página y no se abrió desde una landing concreta, consultá las páginas de la tienda conectada y preguntá por nombre cuál editar. Nunca elijas la primera por defecto. Guarda el código HTML/CSS/JS generado o modificado en la base de datos de Gesicomm. Valida automáticamente las directivas comerciales y sanitiza el código antes de persistirlo. Para cambios puntuales usá seccion_id y revision: conserva otros bloques y su drag and drop. Sincronizá el editor después de guardar.',
    {
      landing_id: z.number().int().positive().optional().describe('ID numérico de la landing'),
      vista: z.enum(['inicio', 'producto', 'catalogo', 'categoria', 'checkout', 'legal']).default('inicio').describe('Vista a actualizar'),
      revision: z.string().optional().describe('Revision devuelta por la lectura; obligatoria para editar una sección.'),
      html: z.string().describe('HTML de la vista o raíz única del bloque indicado en seccion_id'),
      css: z.string().optional().describe('Estilos CSS de la vista'),
      js: z.string().optional().describe('JavaScript de la vista (opcional)'),
      seccion_id: z.string().regex(/^[a-zA-Z0-9_]+$/).optional().describe('Bloque de inicio a leer o editar (ej: anuncios). Omitir al leer para descubrir secciones.'),
      content_id: z.string().optional().describe('Content ID si es la ficha propia de un producto específico'),
    },
    async ({ landing_id, vista, html, css, js, content_id, seccion_id, revision }) => {
      const id = landing_id || defaultLandingId;
      if (!id) {
        try {
          const paginas = (await client.listarLandings()).filter(p => p.es_lienzo_blanco);
          return { content: [{ type: 'text', text: JSON.stringify({
            estado: 'elegir_pagina', pregunta: '¿Qué página de tu tienda querés editar?', paginas,
          }) }] };
        } catch (error) {
          return { isError: true, content: [{ type: 'text', text: error.message }] };
        }
      }
      try {
        const resultado = await client.guardarCodigo(id, {
          vista,
          html,
          css,
          js,
          contentId: content_id,
          seccion_id,
          revision,
        });
        return {
          content: [{
            type: 'text',
            text: JSON.stringify(resultado, null, 2),
          }],
        };
      } catch (err) {
        const detalles = err.detalles?.errores ? `\nErrores encontrados:\n- ${err.detalles.errores.join('\n- ')}` : '';
        return {
          isError: true,
          content: [{ type: 'text', text: `Error al guardar en Gesicomm: ${err.message}${detalles}` }],
        };
      }
    }
  );

  // Tool: Dashboard de Pedidos
  porTienda.tool(
    'gesicomm_dashboard_pedidos',
    'Obtiene métricas y KPIs del dashboard de pedidos (totales, ventas, estados, entrega, devoluciones, top productos) por período o rango de fechas.',
    {
      periodo: z.enum(['hoy', 'ayer', 'ultimos_7_dias', 'este_mes', 'mes_anterior', 'ultimos_30_dias', 'todo']).optional().describe('Período predefinido'),
      fecha_desde: z.string().optional().describe('Fecha inicio YYYY-MM-DD'),
      fecha_hasta: z.string().optional().describe('Fecha fin YYYY-MM-DD'),
      courier_id: z.number().int().positive().optional(),
      producto_id: z.number().int().positive().optional(),
    },
    async (args) => {
      try {
        const datos = await client.dashboardPedidos(args);
        return { content: [{ type: 'text', text: JSON.stringify(datos, null, 2) }] };
      } catch (err) {
        return { isError: true, content: [{ type: 'text', text: `Error consultando dashboard de pedidos: ${err.message}` }] };
      }
    }
  );

  // Tool: Listar Pedidos
  porTienda.tool(
    'gesicomm_listar_pedidos',
    'Lista pedidos/envíos paginados con filtros dinámicos (fechas, estados, cliente, ciudad, courier, origen, producto).',
    {
      pagina: z.number().int().positive().default(1),
      limite: z.number().int().min(1).max(50).default(20),
      periodo: z.enum(['hoy', 'ayer', 'ultimos_7_dias', 'este_mes', 'mes_anterior', 'ultimos_30_dias', 'todo']).optional(),
      fecha_desde: z.string().optional(),
      fecha_hasta: z.string().optional(),
      estados: z.array(z.string()).optional().describe('Estados de envío (ej: pendiente, enviado, entregado, cancelado)'),
      cliente: z.string().optional().describe('Buscar por nombre, teléfono o código'),
      ciudad: z.string().optional(),
      courier_id: z.number().int().positive().optional(),
      origen: z.string().optional().describe('Ej: manual, web, landing'),
      producto_busqueda: z.string().optional(),
    },
    async (args) => {
      try {
        const datos = await client.listarPedidos(args);
        return { content: [{ type: 'text', text: JSON.stringify(datos, null, 2) }] };
      } catch (err) {
        return { isError: true, content: [{ type: 'text', text: `Error listando pedidos: ${err.message}` }] };
      }
    }
  );

  // Tool: Opciones de Pedido
  porTienda.tool(
    'gesicomm_opciones_pedido',
    'Devuelve couriers activos, métodos de pago y orígenes válidos de la tienda para preparar un pedido antes de crearlo.',
    {},
    async () => {
      try {
        const datos = await client.opcionesPedido();
        return { content: [{ type: 'text', text: JSON.stringify(datos, null, 2) }] };
      } catch (err) {
        return { isError: true, content: [{ type: 'text', text: `Error obteniendo opciones de pedido: ${err.message}` }] };
      }
    }
  );

  // Tool: Cargar Pedido (revisar -> guardar)
  porTienda.tool(
    'gesicomm_cargar_pedido',
    'Crea o revisa un pedido/envío en Gesicomm. Usá accion="revisar" primero para validar cliente, ítems y total antes de guardar; luego accion="guardar" tras confirmación del usuario.',
    {
      accion: z.enum(['revisar', 'guardar']).default('revisar'),
      nombre_cliente: z.string().optional(),
      apellido_cliente: z.string().optional(),
      telefono: z.string().optional(),
      ciudad: z.string().optional(),
      departamento: z.string().optional(),
      direccion: z.string().optional(),
      ubicacion_gps: z.string().optional(),
      courier_id: z.number().int().positive().optional(),
      metodo_pago_id: z.number().int().positive().optional(),
      metodo_pago: z.string().optional(),
      pago_anticipado: z.boolean().optional(),
      delivery_a_cargo: z.enum(['cliente', 'negocio']).optional(),
      costo_envio: z.number().min(0).optional(),
      origen: z.enum(['WEB', 'WHATSAPP', 'LANDING', 'TIENDA', 'MANUAL', 'OTRO']).default('MANUAL'),
      observaciones: z.string().optional(),
      items: z.array(z.object({
        producto_id: z.number().int().positive().optional(),
        sku: z.string().optional(),
        nombre_producto: z.string().optional(),
        cantidad: z.number().int().positive().default(1),
        precio_unitario: z.number().min(0).optional(),
      })).min(1).describe('Ítems del pedido'),
    },
    async (args) => {
      try {
        const datos = await client.cargarPedido(args);
        return { content: [{ type: 'text', text: JSON.stringify(datos, null, 2) }] };
      } catch (err) {
        return { isError: true, content: [{ type: 'text', text: `Error al procesar pedido: ${err.message}` }] };
      }
    }
  );

  // Tool: Actualizar Producto
  porTienda.tool(
    'gesicomm_actualizar_producto',
    'Actualiza datos de un producto existente (precio, stock salón/depósito, estado de venta o descripciones) buscándolo por producto_id o sku.',
    {
      producto_id: z.number().int().positive().optional(),
      sku: z.string().optional(),
      nombre: z.string().optional(),
      precio_base: z.number().positive().optional(),
      stock_salon: z.number().int().min(0).optional(),
      stock_deposito: z.number().int().min(0).optional(),
      estado_venta: z.enum(['en_venta', 'fuera_de_stock', 'oculto']).optional(),
      descripcion_corta: z.string().optional(),
      descripcion_larga: z.string().optional(),
      descuento_porcentaje: z.number().min(0).max(99).optional(),
    },
    async (args) => {
      try {
        const datos = await client.actualizarProducto(args);
        return { content: [{ type: 'text', text: JSON.stringify(datos, null, 2) }] };
      } catch (err) {
        return { isError: true, content: [{ type: 'text', text: `Error actualizando producto: ${err.message}` }] };
      }
    }
  );

  // Tool: Crear Landing
  porTienda.tool(
    'gesicomm_crear_landing',
    'Crea una nueva landing (lienzo en blanco) desde cero en la tienda seleccionada, opcionalmente vinculada a productos.',
    {
      titulo: z.string().min(2).describe('Título de la nueva landing'),
      producto_ids: z.array(z.number().int().positive()).optional().describe('IDs numéricos de productos a vincular'),
    },
    async (args) => {
      try {
        const datos = await client.crearLanding(args);
        return { content: [{ type: 'text', text: JSON.stringify(datos, null, 2) }] };
      } catch (err) {
        return { isError: true, content: [{ type: 'text', text: `Error creando landing: ${err.message}` }] };
      }
    }
  );

  // Tool: Publicar Landing
  porTienda.tool(
    'gesicomm_publicar_landing',
    'Publica o despublica una landing en Gesicomm (activo=true para publicar, false para despublicar).',
    {
      landing_id: z.number().int().positive(),
      activo: z.boolean().describe('true para publicar, false para despublicar'),
      aceptar_contenido_ia: z.boolean().optional(),
    },
    async ({ landing_id, activo, aceptar_contenido_ia }) => {
      try {
        const datos = await client.publicarLanding(landing_id, activo, Boolean(aceptar_contenido_ia));
        return { content: [{ type: 'text', text: JSON.stringify(datos, null, 2) }] };
      } catch (err) {
        return { isError: true, content: [{ type: 'text', text: `Error cambiando estado de landing: ${err.message}` }] };
      }
    }
  );

  return server;
}
