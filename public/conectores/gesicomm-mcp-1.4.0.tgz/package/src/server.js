import { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import { z } from 'zod';
import { GesicommApiClient } from './apiClient.js';

import { registrarProductos } from './productos.js';

export function createGesicommServer(config = {}) {
  const client = new GesicommApiClient(config);
  const defaultLandingId = process.env.GESICOMM_LANDING_ID ? Number(process.env.GESICOMM_LANDING_ID) : null;

  const server = new McpServer({
    name: 'gesicomm-mcp',
    version: '1.4.0',
  });

  const resultado = datos => ({ content: [{ type: 'text', text: JSON.stringify(datos) }] });
  server.tool('gesicomm_listar_tiendas', 'Muestra las tiendas propias. Preguntá cuál usar cuando el pedido no la identifique.', {}, async () => resultado(await client.listarTiendas()));
  const porTienda = {
    tool(nombre, descripcion, esquema, ejecutar) {
      server.tool(nombre, descripcion, { ...esquema, tienda_id: z.number().int().positive().optional().describe('Tienda elegida por el usuario para este pedido') }, async args => {
        const tiendas = await client.listarTiendas();
        const id = args.tienda_id ?? args.tienda_confirmada ?? (tiendas.length === 1 ? tiendas[0].id : null);
        if (!tiendas.some(t => t.id === id) || (args.tienda_confirmada && args.tienda_confirmada !== id)) {
          return resultado({ estado: 'elegir_tienda', pregunta: '¿En qué tienda querés trabajar?', tiendas });
        }
        return client.seleccion.run(id, () => ejecutar(args));
      });
    },
  };
  registrarProductos(porTienda, client);

  // Tool 1: Listar Landings
  porTienda.tool(
    'gesicomm_listar_landings',
    'Lista las landings activas y en borrador de la tienda en Gesicomm para conocer sus IDs y títulos.',
    {},
    async () => {
      try {
        const landings = await client.listarLandings();
        return {
          content: [{
            type: 'text',
            text: JSON.stringify(landings, null, 2),
          }],
        };
      } catch (err) {
        return {
          isError: true,
          content: [{ type: 'text', text: `Error al listar landings: ${err.message}` }],
        };
      }
    }
  );

  // Tool 2: Obtener Contexto Comercial Completo
  porTienda.tool(
    'gesicomm_obtener_contexto_landing',
    'Obtiene el contexto comercial completo de la landing: catálogo de productos con precios en Guaraníes (PYG), imágenes, variantes, ofertas (order bumps, packs), branding de la tienda y el contrato técnico de directivas obligatorias para que el carrito, los pedidos y el Píxel funcionen.',
    {
      landing_id: z.number().int().positive().optional().describe('ID numérico de la landing en Gesicomm (si se omite, usa GESICOMM_LANDING_ID)'),
    },
    async ({ landing_id }) => {
      const id = landing_id || defaultLandingId;
      if (!id) {
        return {
          isError: true,
          content: [{ type: 'text', text: 'Debes proporcionar landing_id o configurar GESICOMM_LANDING_ID.' }],
        };
      }
      try {
        const contexto = await client.obtenerContexto(id);
        if (!contexto) {
          throw new Error(`No se pudo obtener el contexto de la landing #${id}. Verificá que la landing exista y pertenezca a tu tienda.`);
        }
        return {
          content: [{
            type: 'text',
            text: JSON.stringify(contexto, null, 2),
          }],
        };
      } catch (err) {
        return {
          isError: true,
          content: [{ type: 'text', text: `Error al obtener contexto comercial de la landing #${id}: ${err.message}` }],
        };
      }
    }
  );

  // Tool 3: Leer Código de la Landing
  porTienda.tool(
    'gesicomm_leer_codigo_landing',
    'Lee el código actual (HTML, CSS, JS) de una vista específica de la landing (inicio, producto, catalogo, categoria, checkout, legal) para poder inspeccionarlo, mejorarlo o modificarlo.',
    {
      landing_id: z.number().int().positive().optional().describe('ID numérico de la landing'),
      vista: z.enum(['inicio', 'producto', 'catalogo', 'categoria', 'checkout', 'legal']).default('inicio').describe('Vista a consultar'),
      seccion_id: z.string().regex(/^[a-zA-Z0-9_]+$/).optional().describe('Bloque de inicio a leer o editar (ej: anuncios). Omitir al leer para descubrir secciones.'),
      content_id: z.string().optional().describe('Para fichas propias de un producto específico, el content_id (ej: "producto-15")'),
    },
    async ({ landing_id, vista, content_id, seccion_id }) => {
      const id = landing_id || defaultLandingId;
      if (!id) {
        return {
          isError: true,
          content: [{ type: 'text', text: 'Debes proporcionar landing_id o configurar GESICOMM_LANDING_ID.' }],
        };
      }
      try {
        const data = await client.obtenerCodigo(id, vista, content_id, seccion_id);
        return {
          content: [{
            type: 'text',
            text: JSON.stringify(data, null, 2),
          }],
        };
      } catch (err) {
        return {
          isError: true,
          content: [{ type: 'text', text: `Error al leer código de la landing #${id}: ${err.message}` }],
        };
      }
    }
  );

  // Tool 4: Validar Motor Comercial
  porTienda.tool(
    'gesicomm_validar_motor_comercial',
    'Audita un fragmento o documento HTML antes de guardarlo, verificando que tenga los botones de compra (data-gesicomm-comprar/agregar), casillas de order bump, selector de variantes y binds de precios necesarios para procesar pedidos y activar el Píxel de Meta.',
    {
      html: z.string().describe('Código HTML a validar'),
      vista: z.enum(['inicio', 'producto', 'catalogo', 'categoria', 'checkout', 'legal']).default('inicio').describe('Vista a validar'),
      landing_id: z.number().int().positive().optional().describe('ID de la landing (opcional)'),
    },
    async ({ html, vista, landing_id }) => {
      const id = landing_id || defaultLandingId;
      try {
        let res;
        if (id) {
          res = await client.validarCodigo(id, html, vista);
        } else {
          // Validación local básica si no hay id
          const tieneComprar = /data-gesicomm-comprar/.test(html) || /data-gesicomm-agregar/.test(html);
          res = {
            valido: tieneComprar,
            errores: tieneComprar ? [] : ['Falta botón de compra: El HTML debe contener data-gesicomm-comprar o data-gesicomm-agregar.'],
            advertencias: [],
            sugerencias: [],
          };
        }
        return {
          content: [{
            type: 'text',
            text: JSON.stringify(res, null, 2),
          }],
        };
      } catch (err) {
        return {
          isError: true,
          content: [{ type: 'text', text: `Error en validación: ${err.message}` }],
        };
      }
    }
  );

  // Tool 5: Guardar Código en Gesicomm
  porTienda.tool(
    'gesicomm_guardar_codigo_landing',
    'Si el pedido no identifica la página y no se abrió desde una landing concreta, consultá las páginas de la tienda conectada y preguntá por nombre cuál editar. Nunca elijas la primera por defecto. Guarda el código HTML/CSS/JS generado o modificado en la base de datos de Gesicomm. Valida automáticamente las directivas comerciales y sanitiza el código antes de persistirlo. Para cambios puntuales usá seccion_id y revision: conserva otros bloques y su drag and drop. Sincronizá el editor después de guardar.',
    {
      landing_id: z.number().int().positive().optional().describe('ID numérico de la landing'),
      vista: z.enum(['inicio', 'producto', 'catalogo', 'categoria', 'checkout', 'legal']).default('inicio').describe('Vista a actualizar'),
      revision: z.string().optional().describe('Revision devuelta por la lectura; obligatoria para editar una sección.'),
      html: z.string().describe('HTML de la vista o raíz única del bloque indicado en seccion_id'),
      css: z.string().optional().describe('Estilos CSS de la vista'),
      js: z.string().optional().describe('JavaScript de la vista (opcional)'),
      seccion_id: z.string().regex(/^[a-zA-Z0-9_]+$/).optional().describe('Bloque de inicio a leer o editar (ej: anuncios). Omitir al leer para descubrir secciones.'),
      content_id: z.string().optional().describe('Content ID si es la ficha propia de un producto específico'),
    },
    async ({ landing_id, vista, html, css, js, content_id, seccion_id, revision }) => {
      const id = landing_id || defaultLandingId;
      if (!id) {
        try {
          const paginas = (await client.listarLandings()).filter(p => p.es_lienzo_blanco);
          return { content: [{ type: 'text', text: JSON.stringify({
            estado: 'elegir_pagina', pregunta: '¿Qué página de tu tienda querés editar?', paginas,
          }) }] };
        } catch (error) {
          return { isError: true, content: [{ type: 'text', text: error.message }] };
        }
      }
      try {
        const resultado = await client.guardarCodigo(id, {
          vista,
          html,
          css,
          js,
          contentId: content_id,
          seccion_id,
          revision,
        });
        return {
          content: [{
            type: 'text',
            text: JSON.stringify(resultado, null, 2),
          }],
        };
      } catch (err) {
        const detalles = err.detalles?.errores ? `\nErrores encontrados:\n- ${err.detalles.errores.join('\n- ')}` : '';
        return {
          isError: true,
          content: [{ type: 'text', text: `Error al guardar en Gesicomm: ${err.message}${detalles}` }],
        };
      }
    }
  );

  return server;
}
