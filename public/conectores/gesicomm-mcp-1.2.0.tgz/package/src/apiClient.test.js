import test from 'node:test';
import assert from 'node:assert/strict';
import { GesicommApiClient } from './apiClient.js';

test('lectura y guardado por sección conservan revision y campos omitidos', async () => {
  const original = globalThis.fetch;
  const requests = [];
  globalThis.fetch = async (url, options) => {
    requests.push({ url, options });
    return { ok: true, text: async () => JSON.stringify({ ok: true }) };
  };
  try {
    const client = new GesicommApiClient({ apiUrl: 'http://localhost:3000/api', token: 'test' });
    await client.obtenerCodigo(12, 'inicio', null, 'anuncios');
    assert.equal(new URL(requests[0].url).searchParams.get('seccion_id'), 'anuncios');
    await client.guardarCodigo(12, { html: '<aside>Nuevo</aside>', seccion_id: 'anuncios', revision: 'abc' });
    const body = JSON.parse(requests[1].options.body);
    assert.equal(body.seccion_id, 'anuncios');
    assert.equal(body.revision, 'abc');
    assert.equal('css' in body, false);
    assert.equal('js' in body, false);
  } finally { globalThis.fetch = original; }
});
