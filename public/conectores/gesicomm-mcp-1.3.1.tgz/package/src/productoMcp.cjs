'use strict';

// Compartido con el conector distribuido: sólo cambia el transporte de la foto.
function esquemaProducto(z, imagen) {
  const texto = limite => z.string().trim().min(1).max(limite);
  const detalle = z.union([texto(80), z.object({
    titulo: texto(80), texto: texto(180).optional(), icono: texto(40).optional(),
  }).strict()]);
  return z.object({
    nombre: texto(255).optional(),
    sku: texto(100).optional().describe('Código del comercio. Si falta se genera uno estable.'),
    precio: z.number().int().min(0).max(999999999999).optional().describe('Precio en guaraníes'),
    stock: z.number().int().min(0).max(2147483647).optional(),
    categoria: texto(100).optional(),
    descripcion: texto(20000).optional(),
    descripcion_corta: texto(500).optional(),
    imagenes: z.array(imagen).max(8).optional().describe('En orden de galería. La primera es la portada.'),
    ficha: z.object({
      propuesta_valor: texto(300).optional(),
      sobre_el_producto: texto(12000).optional(),
      insignia: texto(24).optional(),
      beneficios: z.array(detalle).max(8).optional(),
      confianza: z.array(detalle).max(8).optional(),
      incluye_pedido: z.array(texto(120)).max(8).optional(),
      preguntas: z.array(z.object({ pregunta: texto(300), respuesta: texto(4000) }).strict()).max(20).optional(),
      preguntas_titulo: texto(255).optional(),
      opiniones: z.array(z.object({
        nombre: texto(80), comentario: texto(600), calificacion: z.number().int().min(1).max(5),
        detalle: texto(80).optional(), foto: z.string().url().regex(/^https:\/\//i).optional(),
      }).strict()).max(9).optional().describe('Solo opiniones reales facilitadas por el comercio'),
      textos: z.object(Object.fromEntries(Object.entries({
        insignia_principal: 40, insignia_secundaria: 40, titulo_comercial: 100,
        cta_texto: 60, agregar_carrito_texto: 40, beneficios_kicker: 60, beneficios_titulo: 90,
        beneficios_subtitulo: 180, urgencia_kicker: 60, urgencia_titulo: 90, urgencia_texto: 180,
        opiniones_kicker: 60, opiniones_titulo: 90, opiniones_subtitulo: 180,
        preguntas_kicker: 60, preguntas_titulo: 90, preguntas_subtitulo: 180,
      }).map(([campo, limite]) => [campo, texto(limite).optional()]))).strict().optional(),
    }).strict().optional(),
  }).strict();
}

function revisarProducto(p) {
  const faltan = ['nombre', 'precio', 'stock'].filter(campo => p[campo] == null);
  const sugeridos = [];
  if (!p.imagenes?.length) sugeridos.push('foto principal');
  if (!p.descripcion && !p.descripcion_corta && !p.ficha?.sobre_el_producto) sugeridos.push('descripción');
  if (!p.ficha?.propuesta_valor && !p.ficha?.textos?.titulo_comercial) sugeridos.push('presentación');
  if (!p.ficha?.incluye_pedido?.length) sugeridos.push('qué incluye el pedido');
  if (!p.ficha?.beneficios?.length) sugeridos.push('beneficios');
  if (!p.ficha?.preguntas?.length) sugeridos.push('preguntas frecuentes');
  return { faltan_para_crear: faltan, para_completar_la_ficha: sugeridos };
}

module.exports = { esquemaProducto, revisarProducto };
