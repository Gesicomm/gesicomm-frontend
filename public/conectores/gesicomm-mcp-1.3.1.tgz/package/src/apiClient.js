/**
 * Cliente HTTP para comunicarse con la API de Gesicomm.
 */

export class GesicommApiClient {
  constructor({ apiUrl, token, tiendaId }) {
    let url = (apiUrl || process.env.GESICOMM_API_URL || 'https://api.gesicomm.com/api').trim().replace(/\/+$/, '');
    
    // Si el usuario configuró el dominio del frontend (gesicomm.com), redirigir automáticamente a api.gesicomm.com/api
    if (url === 'https://gesicomm.com' || url === 'http://gesicomm.com' || url === 'https://gesicomm.com/api' || url === 'http://gesicomm.com/api') {
      url = 'https://api.gesicomm.com/api';
    } else if (url === 'https://www.gesicomm.com' || url === 'http://www.gesicomm.com' || url === 'https://www.gesicomm.com/api' || url === 'http://www.gesicomm.com/api') {
      url = 'https://api.gesicomm.com/api';
    } else if (!url.endsWith('/api') && !url.includes('localhost') && !url.includes('127.0.0.1')) {
      url = `${url}/api`;
    }

    this.apiUrl = url;
    this.token = token || process.env.GESICOMM_TOKEN || '';
    this.tiendaId = tiendaId || process.env.GESICOMM_TIENDA_ID || null;
  }

  async _request(path, options = {}) {
    if (!this.token) {
      throw new Error('Falta el token de autenticación de Gesicomm (GESICOMM_TOKEN). Generalo desde Gesicomm > Lienzo en blanco.');
    }

    const url = new URL(`${this.apiUrl}${path}`);
    if (this.tiendaId && !url.searchParams.has('tienda_id')) {
      url.searchParams.set('tienda_id', this.tiendaId);
    }

    const headers = {
      'Authorization': `Bearer ${this.token}`,
      ...(options.body instanceof FormData ? {} : { 'Content-Type': 'application/json' }),
      ...(options.headers || {}),
    };

    const res = await fetch(url.toString(), {
      ...options,
      headers,
    });

    const rawText = await res.text();
    let data;
    try {
      data = JSON.parse(rawText);
    } catch {
      if (rawText.includes('<!DOCTYPE') || rawText.includes('<html')) {
        throw new Error(`El servidor en ${this.apiUrl} respondió con una página HTML en lugar de JSON. Si estás probando en desarrollo local, usá http://localhost:5000/api o asegurate de que el backend en producción tenga desplegados los endpoints /api/mcp.`);
      }
      throw new Error(`Respuesta inválida del servidor (código ${res.status}): ${rawText.substring(0, 150)}`);
    }

    if (!res.ok) {
      const msg = data.error || data.message || `Error en la solicitud a Gesicomm (${res.status})`;
      const err = new Error(msg);
      err.status = res.status;
      err.detalles = data;
      throw err;
    }

    return data;
  }

  async listarLandings() {
    const data = await this._request('/mcp/landings');
    return data.landings || [];
  }

  async tiendaProductos() {
    return this._request('/mcp/productos/tienda');
  }

  async buscarProductos(texto) {
    const data = await this._request('/mcp/productos/buscar?' + new URLSearchParams({ texto }));
    return data.productos;
  }

  async crearProducto(form, tiendaId) {
    return this._request('/mcp/productos?tienda_id=' + tiendaId, { method: 'POST', body: form });
  }

  async obtenerContexto(landingId) {
    const data = await this._request(`/mcp/landings/${landingId}/contexto`);
    return data.contexto;
  }

  async obtenerCodigo(landingId, vista = 'inicio', contentId = null, seccionId = null) {
    const query = new URLSearchParams({ vista });
    if (seccionId) query.set('seccion_id', seccionId);
    if (contentId) query.set('content_id', contentId);
    return this._request(`/mcp/landings/${landingId}/codigo?${query.toString()}`);
  }

  async validarCodigo(landingId, html, vista = 'inicio') {
    return this._request(`/mcp/landings/${landingId}/validar`, {
      method: 'POST',
      body: JSON.stringify({ html, vista }),
    });
  }

  async guardarCodigo(landingId, { vista = 'inicio', html, css, js, contentId = null, seccion_id, revision }) {
    return this._request(`/mcp/landings/${landingId}/codigo`, {
      method: 'POST',
      body: JSON.stringify({ vista, html, css, js, contentId, seccion_id, revision }),
    });
  }
}
