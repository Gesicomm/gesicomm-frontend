import { readFile, stat } from 'node:fs/promises';
import path from 'node:path';
import { z } from 'zod';
import contrato from './productoMcp.cjs';

const maxBytes = 5 * 1024 * 1024;
const foto = z.union([
  z.string().url().max(500).regex(/^https:\/\//i),
  z.object({ base64: z.string().min(4).max(Math.ceil(maxBytes / 3) * 4) }).strict(),
  z.object({ archivo: z.string().min(1) }).strict().describe('Archivo de imagen compartido por el usuario y accesible al cliente local'),
]);
const producto = contrato.esquemaProducto(z, foto);

async function leerFoto(imagen) {
  let bytes;
  if (imagen.archivo) {
    const ruta = imagen.archivo;
    if (!path.isAbsolute(ruta) || /^(?:\\\\|\/\/)/.test(ruta) || !/\.(?:jpe?g|png|webp)$/i.test(ruta)) {
      throw new Error('La foto debe ser un archivo de imagen local adjunto.');
    }
    const info = await stat(ruta);
    if (!info.isFile() || info.size > maxBytes) throw new Error('Cada foto debe pesar como máximo 5 MB.');
    bytes = await readFile(ruta);
  } else {
    bytes = Buffer.from(imagen.base64, 'base64');
    if (bytes.toString('base64') !== imagen.base64) throw new Error('El adjunto no contiene base64 válido.');
  }
  if (bytes.length > maxBytes) throw new Error('La imagen supera los 5 MB.');
  const hex = bytes.subarray(0, 8).toString('hex');
  if (hex === '89504e470d0a1a0a') return new Blob([bytes], { type: 'image/png' });
  if (hex.startsWith('ffd8ff')) return new Blob([bytes], { type: 'image/jpeg' });
  if (bytes.toString('ascii', 0, 4) === 'RIFF' && bytes.toString('ascii', 8, 12) === 'WEBP') return new Blob([bytes], { type: 'image/webp' });
  throw new Error('El adjunto debe ser una foto JPG, PNG o WebP.');
}

export async function prepararEnvio(p) {
  const form = new FormData();
  const imagenes = [];
  let indice = 0;
  for (const imagen of p.imagenes || []) {
    if (typeof imagen === 'string') imagenes.push(imagen);
    else {
      const blob = await leerFoto(imagen);
      form.append('fotos', blob, 'foto.' + blob.type.split('/')[1]);
      imagenes.push({ adjunto: indice++ });
    }
  }
  form.append('producto', JSON.stringify({ ...p, imagenes }));
  return form;
}

export function registrarProductos(server, client) {
  server.tool('gesicomm_buscar_productos', 'Busca productos del catálogo de la tienda por nombre o SKU. Usá el resultado para comprobar si ya están cargados.', {
    texto: z.string().trim().min(1).max(200),
  }, async ({ texto }) => {
    try {
      const productos = await client.buscarProductos(texto);
      return { content: [{ type: 'text', text: JSON.stringify(productos) }] };
    } catch (error) {
      return { isError: true, content: [{ type: 'text', text: error.message }] };
    }
  });
  server.tool('gesicomm_cargar_productos',
    'Prepara o crea uno o varios productos en la tienda conectada con su ficha de lienzo en blanco. Asociá cada foto al producto correcto. Usá los adjuntos que compartió el usuario o sus URLs. Preguntá al usuario en qué tienda quiere cargar los productos. Usá tienda_confirmada solo después de su respuesta. Revisá primero los faltantes y preguntá solo por datos desconocidos. No inventes precios, existencias ni testimonios. Guardar crea productos nuevos, no sobrescribe los existentes. Para lotes grandes, enviá tandas.',
    { accion: z.enum(['revisar', 'guardar']).default('revisar'), tienda_confirmada: z.number().int().positive().optional(), productos: z.array(producto).min(1).max(50) },
    async ({ accion, productos, tienda_confirmada }) => {
      let tienda;
      try { tienda = await client.tiendaProductos(); }
      catch (error) { return { isError: true, content: [{ type: 'text', text: error.message }] }; }
      const confirmada = tienda.id === tienda_confirmada;
      const resultados = [];
      for (const [index, p] of productos.entries()) {
        const fila = { numero: index + 1, nombre: p.nombre, sku: p.sku };
        const revision = contrato.revisarProducto(p);
        if (!confirmada || accion === 'revisar' || revision.faltan_para_crear.length) {
          resultados.push({ ...fila, estado: revision.faltan_para_crear.length ? 'faltan_datos' : (confirmada ? 'listo_para_crear' : 'confirmar_tienda'), ...revision });
          continue;
        }
        try {
          resultados.push({ ...fila, ...await client.crearProducto(await prepararEnvio(p), tienda_confirmada) });
        } catch (error) {
          resultados.push({ ...fila, estado: 'error', error: error.message });
        }
      }
      return { content: [{ type: 'text', text: JSON.stringify({ tienda, pregunta: confirmada ? undefined : '¿Querés cargar estos productos en ' + tienda.nombre + '?', resultados }) }] };
    });
}
